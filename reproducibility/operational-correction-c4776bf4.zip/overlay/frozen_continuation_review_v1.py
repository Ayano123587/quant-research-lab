"""External operational continuation. SOURCE REVIEW ONLY; no dispatch capability.

Imports of numerical/scientific modules occur only inside continue_frozen, which
requires Linux/Kaggle, an externally pinned contract, and the complete checkpoint.
Original scientific source and consumed ledger are never modified.
"""
from __future__ import annotations
import ast
import copy
import hashlib
import inspect
import json
import os
import platform
import shutil
import sys
import textwrap
from datetime import date, datetime
from pathlib import Path, PurePosixPath


def require(value, reason):
    if not value:
        raise ValueError(reason)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def read_json(path):
    def unique(pairs):
        result = {}
        for k, v in pairs:
            require(k not in result, 'duplicate JSON key')
            result[k] = v
        return result
    return json.loads(Path(path).read_bytes(), object_pairs_hook=unique,
        parse_constant=lambda x: (_ for _ in ()).throw(ValueError('nonfinite JSON')))


def safe_path(root, relative):
    p = PurePosixPath(relative)
    require(relative and relative == p.as_posix() and not p.is_absolute()
        and '..' not in p.parts and '\\' not in relative and ':' not in relative,
        'unsafe checkpoint path')
    target = Path(root).joinpath(*p.parts)
    require(not target.is_symlink() and target.resolve().is_relative_to(Path(root).resolve()),
        'checkpoint path escaped root')
    return target


def exclusive_copy(source, target):
    target.parent.mkdir(parents=True, exist_ok=True)
    with source.open('rb') as src, target.open('xb') as dst:
        shutil.copyfileobj(src, dst)
        dst.flush(); os.fsync(dst.fileno())
    require(sha(source) == sha(target), 'checkpoint copy differs')


def contract_checkpoint(contract_path, expected_sha, checkpoint):
    require(sha(contract_path) == expected_sha, 'continuation contract SHA differs')
    c = read_json(contract_path)
    require(c['schema'] == 'shared_quant_operational_continuation_v1'
        and c['original_kernel_id'] == 139401694 and c['original_version'] == 1
        and c['original_runner_sha256'] == 'ad674ddc1b9933f51d1ce4303ecf1c0f4798873f1d680930f48a103dab5baad5'
        and c['selection_performed'] is False and c['original_ledger_immutable'] is True,
        'explicit original attempt continuation contract required')
    require(c['wrapper_sha256'] == sha(__file__), 'wrapper SHA differs')
    receipts = {}
    for r in c['checkpoint_files']:
        name = r['name']; require(name not in receipts, 'duplicate checkpoint receipt')
        p = safe_path(checkpoint, name)
        require(p.is_file() and p.stat().st_size == r['bytes'] and sha(p) == r['sha256'],
            'checkpoint artifact differs')
        receipts[name] = r
    require(set(c['complete_inventory_names']) == set(receipts)
        and len(c['complete_inventory_names']) == len(receipts), 'complete inventory differs')
    actual = {p.relative_to(checkpoint).as_posix() for p in Path(checkpoint).rglob('*') if p.is_file()}
    require(actual == set(receipts), 'unbound checkpoint files')
    return c, receipts


def portable_reviewed_ast_dump(node):
    """CPython3.14 single-line ast.dump(show_empty=False) portable subset.

    Exact reviewed ASTs contain ordinary list-valued fields only. Preserve field
    order and optional-None omission; omit empty lists without _field_types,
    which is absent on the locked Python3.12 runtime. Never alter the AST.
    """
    if isinstance(node, ast.AST):
        fields = []
        for name in node._fields:
            try:
                value = getattr(node, name)
            except AttributeError:
                continue
            if value is None and getattr(type(node), name, ...) is None:
                continue
            if isinstance(value, list) and not value:
                continue
            fields.append(name + '=' + portable_reviewed_ast_dump(value))
        return type(node).__name__ + '(' + ', '.join(fields) + ')'
    if isinstance(node, list):
        return '[' + ', '.join(portable_reviewed_ast_dump(value) for value in node) + ']'
    return repr(node)


def extracted_function(function, mode):
    """Audited mechanical AST slices; original file bytes/callbacks remain intact."""
    module = inspect.getmodule(function)
    tree = ast.parse(textwrap.dedent(inspect.getsource(function)))
    node = tree.body[0]
    require(isinstance(node, ast.FunctionDef), 'expected frozen function')
    node = copy.deepcopy(node)
    if mode == 'fit_receipt_without_model':
        matches = [i for i, n in enumerate(node.body) if isinstance(n, ast.Assign)
            and any(isinstance(t, ast.Attribute) and t.attr == 'model' for t in n.targets)
            and isinstance(n.value, ast.Call) and isinstance(n.value.func, ast.Name)
            and n.value.func.id == '_fit']
        require(len(matches) == 1 and matches[0] == len(node.body) - 3,
            'frozen fit prefix structure differs')
        node.body[matches[0]] = ast.Pass()
        require(not any(isinstance(n, ast.Call) and isinstance(n.func, ast.Name)
            and n.func.id == '_fit' for n in ast.walk(node)), 'learner remains in receipt replay')
    elif mode == 'past_panel_reference_without_covariance':
        require(isinstance(node.body[-2], ast.Assign)
            and isinstance(node.body[-2].value, ast.Call)
            and isinstance(node.body[-2].value.func, ast.Attribute)
            and node.body[-2].value.func.attr == 'forecast', 'frozen panel prefix differs')
        node.body[-2:] = [ast.Return(value=ast.Name(id='reference', ctx=ast.Load()))]
    elif mode == 'report_original_execution':
        tries = [n for n in node.body if isinstance(n, ast.Try)]
        require(len(tries) == 1, 'frozen reporting try structure differs')
        block = tries[0]
        require(isinstance(block.body[0], ast.Assign)
            and isinstance(block.body[0].value, ast.Call)
            and isinstance(block.body[0].value.func, ast.Name)
            and block.body[0].value.func.id == 'run_shared_holdout', 'execution boundary differs')
        block.body = block.body[1:]
        names = ['freeze','registry','providers','execution','output','project','inputs',
            'schedule','release_path','expected_sha256','artifacts']
        node.args = ast.arguments(posonlyargs=[], args=[ast.arg(arg=n) for n in names],
            vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[])
        node.body = [block]
    else:
        raise ValueError('unknown frozen AST extraction')
    node.name = mode
    node.decorator_list = []
    target = ast.fix_missing_locations(ast.Module(body=[node], type_ignores=[]))
    digest = hashlib.sha256(portable_reviewed_ast_dump(target).encode()).hexdigest()
    namespace = dict(vars(module))
    exec(compile(target, str(Path(module.__file__).resolve()) + ':' + mode, 'exec'), namespace)
    namespace[mode].__continuation_ast_source__ = ast.unparse(target)
    return namespace[mode], digest


def continue_frozen(*, contract_path, contract_sha256, checkpoint, release_path,
    release_sha256, project, inputs, schedule, output, dispatch_ticket_path,
    dispatch_ticket_sha256, replay_only=False):
    require(platform.system() == 'Linux' and Path('/kaggle/working').is_dir(),
        'scientific continuation is frozen cloud runtime only')
    checkpoint, output, project = Path(checkpoint), Path(output), Path(project)
    c, receipts = contract_checkpoint(contract_path, contract_sha256, checkpoint)
    require(c['release_sha256'] == release_sha256 and sha(release_path) == release_sha256,
        'original release differs')
    require(sha(dispatch_ticket_path) == dispatch_ticket_sha256, 'original ticket differs')
    ticket = read_json(dispatch_ticket_path)
    require(ticket['host_ledger_entry_sha256'] == c['original_host_ledger_entry_sha256']
        and ticket['release_sha256'] == release_sha256, 'original consumed lineage differs')
    raw_freeze = read_json(release_path)
    for relative,digest in raw_freeze['source_sha256'].items():
        require(sha(safe_path(project,relative))==digest,'frozen source differs before native import')
    for item in raw_freeze['input_files'].values():
        p=safe_path(inputs,item['path'])
        require(p.stat().st_size==item['bytes'] and sha(p)==item['sha256'],
            'frozen input differs before native import')
    from importlib.metadata import version
    require({'python':platform.python_version(),'machine':platform.machine(),
        'packages':{name:version(name) for name in raw_freeze['runtime']['packages']}}
        ==raw_freeze['runtime'],'frozen runtime differs before native import')
    # Native modules are intentionally unreachable until all pinned bytes checked.
    from quantlab.evaluation import holdout as gate
    from quantlab.evaluation import holdout_registry as reg
    from quantlab.evaluation import holdout_pipeline as pipeline
    from quantlab.evaluation import holdout_adapters as adapters
    from quantlab.evaluation.holdout_preparation import DeferredStockProvider, label_timing
    from quantlab.backtest.engine import Decision, EngineResult
    from quantlab.risk.covariance import CovarianceEstimate
    from quantlab.risk.scoring import ReferencePortfolio
    from quantlab.stocks.development import target_from_scores
    import numpy as np
    import pyarrow.parquet as pq

    freeze, registry, providers = reg.build_registry(release_path, release_sha256,
        project=project, inputs=inputs, schedule=schedule)
    gate._authenticate(release_path, release_sha256, project, inputs, registry, schedule)
    window = gate.calendar_window(schedule, gate.START, gate.END)
    declarations = freeze['portfolio_arms'] + freeze.get('forecast_arms', [])
    order = [r['arm_id'] for r in declarations]
    require(len(order) == 250 and len(window.rebalance_signals) == 35
        and len(window.measured_sessions) == 722
        and sum(s['kind'] == 'covariance_proxy' for s in freeze['comparisons']) == 12
        and sum(r['component'] == 'covariance' for r in freeze['portfolio_arms']) == 208,
        'entire original evaluation scope required')
    require(all(r['refit_policy'] in {'none','monthly_expanding_mature'} for r in declarations),
        'transient initial-only models are not restorable by this contract')
    marker_name = 'shared-holdout/' + freeze['release_id'] + '/started.json'
    require(marker_name in receipts and read_json(safe_path(checkpoint, marker_name))['release_sha256']
        == release_sha256, 'authentic original started marker required')
    original_marker = Path('/kaggle/working') / marker_name
    require(not original_marker.exists(), 'existing runtime marker cannot be reset')
    exclusive_copy(safe_path(checkpoint, marker_name), original_marker)
    output.mkdir(parents=True, exist_ok=False)
    lineage_record=pipeline._write(output / 'CONTINUATION.json', {'contract_sha256':contract_sha256,
        'original_kernel_id':139401694,'original_version':1,'new_ledger_consumed':False,
        'original_host_ledger_entry_sha256':c['original_host_ledger_entry_sha256']})
    cached = {}
    for name in receipts:
        prefix = 'shared-final-evaluation/evaluation/streams/'
        if not name.startswith(prefix): continue
        arm, filename = name[len(prefix):].split('/')
        day = date.fromisoformat(Path(filename).stem)
        require(filename == day.isoformat()+'.json' and arm in providers
            and day in window.rebalance_signals, 'unregistered stream')
        cached[arm,day] = name
    flat = [(a,d) for d in window.rebalance_signals for a in order]
    prefix_length = len(cached)
    require(set(flat[:prefix_length]) == set(cached), 'checkpoint is not chronological prefix')
    require(prefix_length == c['completed_stream_prefix_length'], 'pinned replay boundary differs')
    fit_prefix, fit_ast = extracted_function(adapters.StockPanelProvider.fit, 'fit_receipt_without_model')
    panel_prefix, panel_ast = extracted_function(reg.CausalRiskProvider.prepare_forecast,
        'past_panel_reference_without_covariance')
    stock_reference_prefix, stock_reference_ast = extracted_function(reg.StockRiskProvider.prepare_forecast,
        'past_panel_reference_without_covariance')
    report, report_ast = extracted_function(pipeline.run_frozen_pipeline, 'report_original_execution')
    require(c['extracted_ast_sha256'] == {'fit':fit_ast,'panel':panel_ast,
        'stock_reference':stock_reference_ast,'report':report_ast},
        'reviewed extracted code differs')
    histories = {}
    for row in declarations:
        w = providers[row['arm_id']]
        w.export_root = output/'streams'/w.arm_id
        histories[w.arm_id] = registry[w.arm_id].load(row['input_id'],window)
        require(histories[w.arm_id].source_identity.as_dict() == row['source_identity'],
            'history source identity differs')
        w.initialize_stream(window)
    bindings = {a: w.stream_exports for a,w in providers.items()}
    for w in providers.values():
        if hasattr(w.provider,'bind_forecast_exports'): w.provider.bind_forecast_exports(bindings)
    def plain(value): return pipeline._plain(value)
    def equal(a,b):
        require(json.dumps(plain(a),sort_keys=True,allow_nan=False)
            == json.dumps(plain(b),sort_keys=True,allow_nan=False), 'cached value differs on replay')
    def canonical_clock(raw,attribute,expected_day=None):
        parsed=datetime.fromisoformat(raw)
        day=parsed.date() if expected_day is None else expected_day
        canonical=getattr(schedule.session(day),attribute)
        require(raw==canonical.isoformat(),'serialized clock differs from exact frozen schedule clock')
        return canonical
    def decision(raw):
        return Decision(raw['action'], None if raw['target'] is None else tuple(tuple(x) for x in raw['target']),
            canonical_clock(raw['signal_at'],'decision_at'),canonical_clock(raw['intended_execution_at'],'open_at'),raw['reason'])
    def prediction(raw):
        require(set(raw)=={'session','signal_at','fit_id','scores'}, 'prediction schema differs')
        day=date.fromisoformat(raw['session'])
        # Preserve ORIGINAL dict insertion order too: source serializes this
        # prediction through repr(), whereas cached JSON sorted its keys.
        return {'session':day,
            # Original stock predictions store view.cutoff directly. Its exact
            # tzinfo representation participates in StockRisk's repr-based input_id.
            'signal_at':canonical_clock(raw['signal_at'],'decision_at',day),
            'fit_id':raw['fit_id'],
            'scores':tuple(tuple(x) for x in raw['scores'])}
    def reference(raw,day):
        return ReferencePortfolio(tuple(raw['asset_ids']),tuple(raw['weights']),
            canonical_clock(raw['known_at'],'decision_at',day),
            canonical_clock(raw['max_input_available_at'],'decision_at',day),
            raw['rule_id'],raw['input_id'])
    def covariance(raw):
        raw = dict(raw)
        for key in ('matrix','location'):
            raw[key] = np.asarray(raw[key],dtype=np.float64)
            require(np.isfinite(raw[key]).all(),'nonfinite saved covariance')
            raw[key].setflags(write=False)
        raw['asset_ids']=tuple(raw['asset_ids'])
        for key in ('signal_at','max_available_at'):raw[key]=canonical_clock(raw[key],'decision_at')
        for key in ('training_start','training_end'):raw[key]=canonical_clock(raw[key],'close_at')
        raw['fitted_at']=datetime.fromisoformat(raw['fitted_at'])
        value=CovarianceEstimate(**raw)
        require(value.matrix.shape==(len(value.asset_ids),)*2 and value.location.shape==(len(value.asset_ids),),
            'covariance shape differs')
        return value
    def stock_memo(w):
        source=getattr(w.provider,'stock',w.provider)
        return source if isinstance(source,reg.StockSignalMemo) else None
    def import_derived(memo,day):
        deferred=memo.provider
        require(isinstance(deferred,DeferredStockProvider),'expected deferred source')
        origin='shared-final-evaluation/evaluation/derived-stock/'+deferred.root.name+'/'
        for name,r in receipts.items():
            if not name.startswith(origin): continue
            parts=PurePosixPath(name[len(origin):]).parts
            require(len(parts)==2,'derived path schema differs')
            kind,filename=parts; d=date.fromisoformat(Path(filename).stem)
            if d>day: continue
            if kind=='labels':
                if d>=day or label_timing(schedule,d)[1].decision_at>schedule.session(day).decision_at: continue
                if d>=gate.START: deferred._prior_exports(d)
            elif kind not in {'features','wider_features','eligibility'}: raise ValueError('unknown derived kind')
            target=deferred.root/kind/filename
            if kind=='eligibility':
                if d in deferred.eligibility_artifacts: continue
                require(filename==d.isoformat()+'.json','eligibility name differs')
                value=read_json(safe_path(checkpoint,name))
                require(value['population']==7195 and value['selection_uses_outcomes'] is False,
                    'eligibility policy differs')
                exclusive_copy(safe_path(checkpoint,name),target)
                deferred.eligibility_artifacts[d]={'path':str(target),'bytes':r['bytes'],'sha256':r['sha256']}
                continue
            if (kind,d) in deferred.generated: continue
            require(filename==d.isoformat()+'.parquet','partition name differs')
            parquet=pq.ParquetFile(safe_path(checkpoint,name))
            metadata=parquet.read(columns=['asset_id','signal_session']).to_pylist()
            require(len({v['asset_id'] for v in metadata})==len(metadata)
                and all(v['signal_session']==d for v in metadata), 'partition cohort identity differs')
            exclusive_copy(safe_path(checkpoint,name),target)
            item={'path':str(target),'kind':kind,'session':str(d),'rows':len(metadata),
                'bytes':r['bytes'],'sha256':r['sha256'],'release_sha256':release_sha256}
            deferred.actual.partitions[kind,d]=target
            deferred.actual.partition_identity[target]=(r['bytes'],r['sha256'])
            deferred.generated[kind,d]=item
    declaration_by_id={r['arm_id']:r for r in declarations}
    replay_gate_written=False
    def replay_gate():
        nonlocal replay_gate_written
        require(not replay_gate_written,'replay gate is exclusive')
        require(sum(len(w.stream_exports) for w in providers.values())==prefix_length,
            'restored prefix count differs')
        require(all(sha(providers[a].stream_exports[d]['path'])==receipts[name]['sha256']
            for (a,d),name in cached.items()),'restored prefix bytes differ')
        # Frame every field/date separately. At most one dated covariance register
        # is converted to Python lists; no all-provider/period plaintext exists.
        state_digest=hashlib.sha256()
        encoder=json.JSONEncoder(sort_keys=True,allow_nan=False,separators=(',',':'),ensure_ascii=True)
        hashing_schema='typed_state_per_arm_field_date_framed_json_v1'
        state_digest.update((hashing_schema+'\n').encode())
        def hash_chunk(arm,field,day,value):
            label=json.dumps([arm,field,day],separators=(',',':'),ensure_ascii=True).encode()
            state_digest.update(str(len(label)).encode()+b':'+label+b'\n')
            # JSON strings escape literal newlines. The record newline is an
            # unambiguous boundary after this complete JSON value.
            converted=plain(value)
            for fragment in encoder.iterencode(converted):state_digest.update(fragment.encode())
            state_digest.update(b'\n')
        for a in sorted(providers):
            w=providers[a];memo=stock_memo(w)
            forecasts=getattr(getattr(w.provider,'forecast_provider',None),'forecasts',{})
            references=getattr(getattr(w.provider,'forecast_provider',None),'references',{})
            for field,register in (('targets',w.targets),('fits',w.fit_receipts),
                ('stream_status',w.stream_status),('risk_forecasts',forecasts),('risk_references',references)):
                hash_chunk(a,field,None,{'entry_count':len(register)})
                for d in sorted(register):hash_chunk(a,field,d.isoformat(),register[d])
            predictions=() if memo is None else memo.provider.actual.predictions
            hash_chunk(a,'predictions',None,{'entry_count':len(predictions)})
            for prediction_index,item in enumerate(predictions):
                hash_chunk(a,'predictions',str(prediction_index),item)
        state_sha=state_digest.hexdigest()
        pipeline._write(output/'REPLAY-VERIFIED.json',{'restored_stream_records':prefix_length,
            'typed_state_sha256':state_sha,'typed_state_hashing_schema':hashing_schema,
            'next_missing_pair':None if prefix_length==len(flat)
                else [flat[prefix_length][0],flat[prefix_length][1].isoformat()],
            'model_fit_calls_during_cached_replay':0,'economic_or_outcome_consumers_run':False,
            'original_checkpoint_files_verified':len(receipts),'all_original_scope_required':True,
            'replay_only_requested':bool(replay_only),'extracted_ast_sha256':c['extracted_ast_sha256']})
        replay_gate_written=True
    for index,(arm,day) in enumerate(flat):
        w=providers[arm]
        if index>=prefix_length:
            if not replay_gate_written:
                replay_gate()
                if replay_only: return {'replay_verified':True,'global_protocol_complete':False}
            w.step_signal(day)
            continue
        name=cached[arm,day]; raw=read_json(safe_path(checkpoint,name))
        require(raw['session']==day.isoformat() and raw['status'] in {'forecast_exported','unsupported_forecast'},
            'cached terminal record schema differs')
        view=w.loader.view(day,schedule); memo=stock_memo(w); key=(day,view.cutoff)
        if memo is not None:
            import_derived(memo,day)
            if hasattr(w.provider,'prepare_features'): w.provider.prepare_features(view)
            if declaration_by_id[arm]['refit_policy']=='monthly_expanding_mature':
                selected=gate.mature_training_keys(w.provider.clocks(view),signal_session=day,decision_at=view.cutoff)
                stock=memo.provider.actual
                supported=len(selected.keys)>=stock.minimum_rows and len({d for d,_ in selected.keys})>=stock.minimum_dates
                if supported:
                    if key not in memo.fits:
                        receipt=fit_prefix(stock,view,selected)
                        memo.fits[key]=(receipt,selected); memo.latest_fit=key
                    receipt,original=memo.fits[key]; equal(original,selected)
                    if raw['status']=='forecast_exported':
                        require(raw.get('fit') is not None,'supported learned forecast lacks fit receipt')
                    if raw.get('fit') is not None: equal(receipt,raw['fit'])
                    w.fit_receipts[day]=receipt
                else:
                    require(raw['status']=='unsupported_forecast' and raw['support_code']=='insufficient_mature_training_support',
                        'cached support differs')
            predictions=[prediction(v) for v in raw.get('predictions',[])]
            existing=[v for v in memo.provider.actual.predictions if v['session']==day]
            if existing: equal(existing,predictions)
            else: memo.provider.actual.predictions.extend(predictions)
            if predictions:
                require(len(predictions)==1 and predictions[0]['session']==day
                    and predictions[0]['signal_at']==view.cutoff,'saved prediction clock differs')
                if declaration_by_id[arm]['refit_policy']=='monthly_expanding_mature':
                    require(day in w.fit_receipts and predictions[0]['fit_id']==w.fit_receipts[day].fit_id,
                        'prediction differs from authenticated monthly fit identity')
                else:
                    require(predictions[0]['fit_id']=='registered_unfitted_control','control fit identity differs')
                target=target_from_scores(predictions[0]['scores'],view.cutoff,view.next_open_at,memo.provider.actual.spec)
                if key in memo.targets: equal(memo.targets[key],target)
                else: memo.targets[key]=target
                if isinstance(w.provider,reg.StockRiskProvider): w.provider.equal_targets[day]=target
                else:
                    require(raw.get('target') is not None,'stock target missing'); equal(target,raw['target'])
                    w.targets[day]=target
        if raw['status']=='forecast_exported':
            if isinstance(w.provider,(adapters.ETFProvider,adapters.SensitivityProvider)):
                target=w.provider.decide(view,None); equal(target,raw['target']); w.targets[day]=target
            if 'forecasts' in raw:
                ref=reference(raw['reference'],day)
                if isinstance(w.provider,reg.CausalRiskProvider): equal(panel_prefix(w.provider,view),ref)
                if isinstance(w.provider,reg.StockRiskProvider): equal(stock_reference_prefix(w.provider,view),ref)
                forecasts={k:covariance(v) for k,v in raw['forecasts'].items()}
                equal(forecasts,raw['forecasts']); equal(ref,raw['reference'])
                f=w.provider.forecast_provider
                require(set(forecasts)==set(f.parameters),'saved estimator set differs')
                for k,v in forecasts.items():
                    expected=f.parameters[k]
                    require(v.method==expected['method'] and all(v.parameters.get(t)==expected[t]
                        for t in ('min_observations','relative_tolerance','absolute_tolerance')),
                        'saved estimator method/base parameters differ')
                    if v.method=='ewma': require(v.parameters['lambda_']==expected['ewma_lambda'],'EWMA differs')
                    if v.method=='pca_factor':
                        require(v.parameters['n_factors']==expected['n_factors']
                            and v.parameters['residual_floor']==expected['residual_floor'],'PCA differs')
                    if v.method=='constant_correlation':
                        require(v.parameters['shrinkage']==expected['constant_correlation_intensity'],'shrinkage differs')
                    require(v.configuration_hash==hashlib.sha256(json.dumps(
                        {'method':v.method,'parameters':v.parameters},sort_keys=True).encode()).hexdigest(),
                        'saved covariance configuration identity differs')
                    require(v.asset_ids==ref.asset_ids and v.signal_at==view.cutoff
                        and v.max_available_at<=view.cutoff
                        and v.source_provenance['source_snapshot_id']==f.identity.source_id,
                        'saved forecast information/source boundary differs')
                f.references[day]=ref; f.forecasts[day]=forecasts
            elif hasattr(w.provider,'forecast_provider'):
                # Stock HOLD legitimately has no forecast; economics returns equal HOLD first.
                require(isinstance(w.provider,reg.StockRiskProvider)
                    and w.provider.equal_targets[day].action=='HOLD','missing risk forecast')
        else:
            require(raw['support_code'] in reg.ForecastSupportError.CODES,'unknown support code')
            if isinstance(w.provider,reg.CausalRiskProvider):
                try: panel_prefix(w.provider,view)
                except reg.ForecastSupportError as exc: equal(exc.code,raw['support_code'])
                else: raise ValueError('cached unsupported panel became supported')
        target=Path(w.export_root)/(day.isoformat()+'.json')
        exclusive_copy(safe_path(checkpoint,name),target)
        w.stream_status[day]=raw['status']
        w.stream_exports[day]={'path':str(target),'bytes':receipts[name]['bytes'],'sha256':receipts[name]['sha256']}
    if not replay_gate_written:
        replay_gate()
        if replay_only: return {'replay_verified':True,'global_protocol_complete':False}
    for w in providers.values(): w.finalize_stream()
    results,fits={},{}
    for row in freeze['portfolio_arms']:
        a=row['arm_id']; w=providers[a]
        missing=tuple((d,read_json(w.stream_exports[d]['path'])['support_code'])
            for d,status in w.stream_status.items() if status=='unsupported_forecast')
        if missing:
            results[a]=gate.PortfolioNotExecuted(gate.START,gate.END,missing)
            fits[a]=tuple(w.fit_receipts.values())
        else:
            results[a],fits[a]=gate._execute(histories[a],schedule,window,registry[a],
                row['refit_policy'],freeze['initial_cash'],row['fee_bps'])
    gate._authenticate(release_path,release_sha256,project,inputs,registry,schedule)
    execution={'release_sha256':release_sha256,'window':window,'results':results,'fits':fits,
        'portfolio_execution_support_complete':all(isinstance(v,EngineResult) and v.failure is None
            and v.incomplete_day is None and tuple(x.session for x in v.daily[1:])==window.measured_sessions
            for v in results.values()),'global_holdout_complete':False,
        'outcome_evaluation':'separate_after_frozen_predictions_not_run_here',
        'economic_source_receipts':{r['arm_id']:gate.economic_source_receipt(histories[r['arm_id']])
            for r in freeze['portfolio_arms']},
        'forecast_only_arms':tuple(r['arm_id'] for r in freeze.get('forecast_arms',[]))}
    manifest=report(freeze,registry,providers,execution,output,project,inputs,schedule,
        release_path,release_sha256,{'CONTINUATION.json':lineage_record})
    require(manifest['global_protocol_complete'] is True and manifest['selection_performed'] is False,
        'all registered consumers must complete')
    return manifest


def main():
    import argparse
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--config',required=True); p.add_argument('--config-sha256',required=True)
    args=p.parse_args()
    require(sha(args.config)==args.config_sha256,'invocation config differs')
    c=read_json(args.config)
    require(platform.system()=='Linux' and Path('/kaggle/working').is_dir(),'cloud only')
    sys.path.insert(0,str(Path(c['project'])/'src'))
    from quantlab.data.calendar import XNYSSchedule
    calendar=c.pop('calendar')
    schedule=XNYSSchedule(date.fromisoformat(calendar['start']),date.fromisoformat(calendar['end']))
    require(schedule.provenance==calendar,'calendar differs')
    continue_frozen(schedule=schedule,**c)

if __name__=='__main__': main()
