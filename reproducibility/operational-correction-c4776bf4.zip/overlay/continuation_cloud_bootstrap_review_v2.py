"""SOURCE REVIEW ONLY. Bootstrap exact original packaging, then external continuation.
No provider APIs, upload, staging or dispatch functionality is present.
"""
import argparse
import ast
import copy
import hashlib
import importlib.util
import json
import os
import platform
import stat
import subprocess
import time
import zipfile
from datetime import datetime, UTC
from pathlib import Path
from frozen_continuation_review_v1 import require, sha, read_json, safe_path


def packaging_prefix(original):
    node=next(n for n in ast.parse(Path(original.__file__).read_text()).body
        if isinstance(n,ast.FunctionDef) and n.name=='run')
    node=copy.deepcopy(node)
    block=next(n for n in node.body if isinstance(n,ast.Try))
    end=next(i for i,n in enumerate(block.body) if isinstance(n,ast.Assign)
        and any(isinstance(t,ast.Name) and t.id=='log' for t in n.targets))
    require(isinstance(block.body[end-1],ast.Assign)
        and isinstance(block.body[end-1].targets[0],ast.Subscript), 'original bootstrap boundary differs')
    names=['project','inputs','interpreter','environment','plan','deadline','private']
    block.body=block.body[:end]+[ast.Return(ast.Dict(
        keys=[ast.Constant(x) for x in names],values=[ast.Name(x,ast.Load()) for x in names]))]
    node.name='original_packaging_prefix'
    tree=ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[]))
    pin=hashlib.sha256(ast.dump(tree,include_attributes=False).encode()).hexdigest()
    namespace=dict(vars(original)); exec(compile(tree,original.__file__+':packaging-prefix','exec'),namespace)
    return namespace[node.name],pin


def extract_checkpoint(archive, archive_sha, destination, contract, budget):
    require(sha(archive)==archive_sha,'whole checkpoint ZIP differs')
    destination.mkdir(parents=True,exist_ok=False)
    expected={r['name']:r for r in contract['checkpoint_files']}
    require(len(expected)==len(contract['checkpoint_files']),'duplicate checkpoint receipts')
    total=0; seen=set()
    with zipfile.ZipFile(archive) as z:
        for item in z.infolist():
            budget()
            if item.is_dir(): continue
            name=item.filename; path=safe_path(destination,name)
            require(name in expected and name not in seen,'unbound or duplicate ZIP member')
            mode=item.external_attr>>16
            require(not stat.S_ISLNK(mode),'ZIP symlink forbidden')
            require(item.file_size==expected[name]['bytes'] and item.file_size<=contract['max_checkpoint_member_bytes'],
                'ZIP member bound differs')
            total+=item.file_size
            require(total<=contract['max_checkpoint_expanded_bytes'],'ZIP expansion bound exceeded')
            require(name.startswith('shared-final-evaluation/') or name==contract['original_started_marker_name'],
                'ZIP scope differs')
            require(Path(name).suffix.lower() not in {'.pkl','.pickle','.joblib','.pt','.pth','.ckpt',
                '.safetensors','.h5','.hdf5','.onnx','.npy','.npz','.bin'},'native weight payload forbidden')
            path.parent.mkdir(parents=True,exist_ok=True)
            digest=hashlib.sha256(); count=0
            with z.open(item) as src,path.open('xb') as dst:
                for chunk in iter(lambda:src.read(1024*1024),b''):
                    budget()
                    count+=len(chunk); require(count<=item.file_size,'ZIP member expanded beyond header')
                    digest.update(chunk); dst.write(chunk)
                dst.flush();os.fsync(dst.fileno())
            require(count==item.file_size and digest.hexdigest()==expected[name]['sha256'],'ZIP content differs')
            seen.add(name)
    require(seen==set(expected),'ZIP lacks complete checkpoint inventory')


def runtime_probe(prepared, original_runner, output, label, budget):
    expected=prepared['private']/('runtime-expected-'+label+'.json')
    with expected.open('x') as f:json.dump(prepared['plan']['runtime'],f)
    script=("import importlib.util,json,sys;"
        "s=importlib.util.spec_from_file_location('original_runtime_probe',sys.argv[1]);"
        "m=importlib.util.module_from_spec(s);s.loader.exec_module(m);"
        "print(json.dumps(m.runtime(json.load(open(sys.argv[2]))),sort_keys=True))")
    result=subprocess.run([str(prepared['interpreter']),'-c',script,original_runner,str(expected)],
        env=prepared['environment'],cwd='/kaggle/working',capture_output=True,text=True,
        check=True,timeout=budget())
    require(len(result.stdout)<65536 and len(result.stderr)<65536,'runtime probe output bound')
    actual=json.loads(result.stdout)
    require(actual==prepared['plan']['runtime'],'actual frozen interpreter runtime differs')
    path=output/('runtime-'+label+'.json')
    with path.open('x') as f:
        json.dump({'actual':actual,'interpreter':str(prepared['interpreter']),
            'observed_at':datetime.now(UTC).isoformat(),'probe':'original.runtime'},f,sort_keys=True)
        f.flush();os.fsync(f.fileno())
    return actual


def execute(c):
    require(platform.system()=='Linux' and Path('/kaggle/working').is_dir(),'bootstrap is cloud only')
    require(sha(__file__)==c['bootstrap_sha256'],'bootstrap source differs')
    require(sha(c['original_runner'])=='ad674ddc1b9933f51d1ce4303ecf1c0f4798873f1d680930f48a103dab5baad5',
        'exact original runner bytes required')
    require(sha(c['contract_path'])==c['contract_sha256'],'continuation contract differs')
    contract=read_json(c['contract_path'])
    require(sha(c['wrapper_path'])==contract['wrapper_sha256'],'external wrapper differs')
    require(Path(c['checkpoint_zip']).stat().st_size<=contract['max_checkpoint_archive_bytes'],
        'checkpoint archive exceeds reviewed bound')
    spec=importlib.util.spec_from_file_location('exact_original_bootstrap',c['original_runner'])
    original=importlib.util.module_from_spec(spec);spec.loader.exec_module(original)
    prefix,pin=packaging_prefix(original)
    require(pin==c['original_packaging_prefix_ast_sha256'],'reviewed bootstrap extraction differs')
    # Executes original authentication, input extraction, wider-parent verification,
    # and exact locked runtime bootstrap. It returns BEFORE original scientific child.
    prepared=prefix(c['input_root'],c['output_root'])
    stage='packaging_complete'
    output=Path(c['output_root'])
    def budget():
        left=prepared['deadline']-time.monotonic()
        require(left>0,'startup inclusive deadline exhausted')
        return left
    def event(value):
        with (output/'continuation-stages.jsonl').open('a') as f:
            f.write(json.dumps({'stage':value,'remaining_seconds':budget(),
                'observed_at':datetime.now(UTC).isoformat()},sort_keys=True)+'\n')
            f.flush();os.fsync(f.fileno())
    try:
        event(stage)
        return post_bootstrap(c,prepared,original,budget,event)
    except BaseException as error:
        failure=output/'CONTINUATION_FAILURE.json'
        if not failure.exists():
            with failure.open('x') as f:
                json.dump({'complete':False,'error_type':type(error).__name__,
                    'last_stage':read_last_stage(output),'remaining_seconds':prepared['deadline']-time.monotonic(),
                    'original_ledger_immutable':True,'automatic_retry':False},f,sort_keys=True)
                f.flush();os.fsync(f.fileno())
        raise


def read_last_stage(output):
    path=output/'continuation-stages.jsonl'
    if not path.exists():return 'packaging_complete'
    return json.loads(path.read_text().splitlines()[-1])['stage']


def post_bootstrap(c,prepared,original,budget,event):
    output=Path(c['output_root'])
    contract=read_json(c['contract_path'])
    require(prepared['plan']['release_sha256']==contract['release_sha256'],'original plan/release differs')
    event('runtime_before_child')
    runtime_before=runtime_probe(prepared,c['original_runner'],output,'before-continuation',budget)
    private=prepared['private']; checkpoint=private/'original-checkpoint'
    event('checkpoint_extract')
    extract_checkpoint(c['checkpoint_zip'],contract['checkpoint_archive_sha256'],checkpoint,contract,budget)
    budget()
    wrapper_config={'contract_path':c['contract_path'],'contract_sha256':c['contract_sha256'],
        'checkpoint':str(checkpoint),'release_path':str(prepared['project']/'release/final-release.json'),
        'release_sha256':prepared['plan']['release_sha256'],'project':str(prepared['project']),
        'inputs':str(prepared['inputs']),'calendar':prepared['plan']['calendar'],
        'output':str(Path(c['output_root'])/'evaluation'),
        'dispatch_ticket_path':str(prepared['project']/'release/ticket.json'),
        'dispatch_ticket_sha256':prepared['plan']['ticket_sha256'],'replay_only':bool(c.get('replay_only',False))}
    require(Path(wrapper_config['release_path']).is_file(),'actual original release path required')
    path=private/'continuation-invocation.json'
    original.write_json(path,wrapper_config)
    remaining=budget()
    log=Path(c['output_root'])/'child.log'
    event('continuation_child')
    with log.open('xb') as stream:
        subprocess.run([str(prepared['interpreter']),c['wrapper_path'],'--config',str(path),
            '--config-sha256',sha(path)],env=prepared['environment'],cwd='/kaggle/working',
            timeout=remaining,check=True,stdout=stream,stderr=subprocess.STDOUT)
    budget()
    event('postflight_source_authentication')
    original.authenticate_project(prepared['project'],prepared['plan'])
    budget()
    event('postflight_actual_runtime')
    runtime_after=runtime_probe(prepared,c['original_runner'],output,'after-continuation',budget)
    require(runtime_after==runtime_before,'runtime changed during continuation')
    budget()
    require((Path(c['output_root'])/'evaluation'/'REPLAY-VERIFIED.json').is_file(),
        'typed replay verification required')
    replay=read_json(output/'evaluation'/'REPLAY-VERIFIED.json')
    require(replay['restored_stream_records']==contract['completed_stream_prefix_length']
        and replay['model_fit_calls_during_cached_replay']==0
        and replay['economic_or_outcome_consumers_run'] is False
        and replay['original_checkpoint_files_verified']==len(contract['checkpoint_files']),
        'typed replay gate content differs from pinned contract')
    if c.get('replay_only',False):
        event('replay_only_complete')
        original.write_json(Path(c['output_root'])/'REPLAY-ONLY.json',{'global_protocol_complete':False,
            'replay_verified':True,'original_ledger_immutable':True})
    else:
        event('scientific_manifest_verification')
        evaluation=output/'evaluation'
        require((evaluation/'COMPLETE').is_file() and (evaluation/'manifest.json').is_file(),
            'all consumer completion required')
        complete=read_json(evaluation/'COMPLETE');manifest=read_json(evaluation/'manifest.json')
        require(complete['manifest_sha256']==sha(evaluation/'manifest.json')
            and complete['global_protocol_complete'] is True,'completion receipt/manifest differs')
        require(manifest['global_protocol_complete'] is True
            and manifest['selection_performed'] is False
            and manifest['release_sha256']==prepared['plan']['release_sha256'],
            'full unchanged scientific protocol completion required')
        budget()
        event('outer_complete')
        original.write_json(Path(c['output_root'])/'COMPLETE.json',{'global_protocol_complete':True,
            'original_kernel_id':139401694,'original_version':1,'contract_sha256':c['contract_sha256'],
            'manifest_sha256':sha(evaluation/'manifest.json'),'release_sha256':manifest['release_sha256'],
            'runtime_after_receipt_sha256':sha(output/'runtime-after-continuation.json')})


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--config',required=True);p.add_argument('--config-sha256',required=True)
    a=p.parse_args()
    require(sha(a.config)==a.config_sha256,'bootstrap invocation config differs')
    c=read_json(a.config)
    execute(c)

if __name__=='__main__':main()
