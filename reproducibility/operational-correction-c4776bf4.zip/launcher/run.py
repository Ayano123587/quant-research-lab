"""SOURCE TEMPLATE: binding required before ROOT-approved cloud dispatch."""
import hashlib
import importlib.util
import json
import os
import shutil
import sys
from pathlib import Path

BUNDLE_MANIFEST_SHA256 = 'c10a7adb5637546baefb2f76b35fc3affd7c34f1cd398e7c1e0e40702e672e03'

def check(value,reason):
    if not value:raise ValueError(reason)

def digest(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def safe_basename(name):
    check(isinstance(name,str) and name not in ('','.','..')
        and Path(name).name==name and ':' not in name and '\\' not in name,
        'safe exact bundle basename required')


def external_assets(manifest,input_root):
    carrier=manifest['external_carrier']
    check(carrier=={'dataset':'aikyatansinha/quant-continuation-source-2419dc3c',
        'dataset_id':12685279,'version':1,'manifest_name':'continuation-bundle-manifest.json',
        'manifest_sha256':'2419dc3c2760899ce9571e519a7b55be6f96b68d693bdc96770dbdae8ee76870'},
        'exact original authenticated carrier binding required')
    # Numeric/version identity is ROOT-reviewed metadata; mounted bytes prove contents.
    slug=carrier['dataset'].split('/')[1]
    matches=[path for path in input_root.rglob(carrier['manifest_name'])
        if slug in path.relative_to(input_root).parts[:-1]
        and path.is_file() and not path.is_symlink()
        and digest(path)==carrier['manifest_sha256']]
    check(len(matches)==1,'exact one original carrier manifest required')
    old_path=matches[0];old_root=old_path.parent
    old=json.loads(old_path.read_bytes())
    check(old['schema']=='shared_quant_continuation_bundle_v1','original carrier schema differs')
    pins={}
    for row in old['files']:
        safe_basename(row['name']);check(row['name'] not in pins,'duplicate carrier asset')
        path=old_root/row['name']
        check(path.is_file() and not path.is_symlink()
            and not any(parent.is_symlink() for parent in path.parents),'regular carrier asset required')
        check(path.stat().st_size==row['bytes'] and digest(path)==row['sha256'],
            'entire original carrier asset differs')
        pins[row['name']]=row
    actual={path.relative_to(old_root).as_posix() for path in old_root.rglob('*') if path.is_file()}
    check(actual==set(pins)|{carrier['manifest_name']},'exact original carrier file inventory required')
    requested=manifest['external_files']
    check({row['name'] for row in requested}=={'checkpoint-payload.bin','original-runner-ad674.py'}
        and len(requested)==2,'only original checkpoint and original runner may be external')
    result={}
    for row in requested:
        check(row==pins[row['name']],'external asset must retain exact original manifest pin')
        result[row['name']]=old_root/row['name']
    return result


def main():
    check(len(BUNDLE_MANIFEST_SHA256)==64,'reviewed bundle manifest SHA required')
    candidates=[p for p in Path('/kaggle/input').rglob('continuation-bundle-manifest.json')
        if p.is_file() and not p.is_symlink() and digest(p)==BUNDLE_MANIFEST_SHA256]
    check(len(candidates)==1,'one bound continuation bundle required')
    manifest_path=candidates[0]; root=manifest_path.parent
    manifest=json.loads(manifest_path.read_bytes())
    check(manifest['schema']=='shared_quant_continuation_bundle_v2_external_carrier','bundle schema differs')
    external=external_assets(manifest,Path('/kaggle/input'))
    destination=Path('/kaggle/working/continuation-code');destination.mkdir(exist_ok=False)
    locations={}
    local_names={row['name'] for row in manifest['files']}
    check(len(local_names)==len(manifest['files']) and not local_names.intersection(external),
        'exact disjoint local/external source inventory required')
    actual={path.relative_to(root).as_posix() for path in root.rglob('*') if path.is_file()}
    check(actual==local_names|{'continuation-bundle-manifest.json'},'exact overlay file inventory required')
    for item in [*manifest['files'],*manifest['external_files']]:
        name=item['name'];check(Path(name).name==name and ':' not in name and '\\' not in name,'safe basename required')
        check(name not in locations,'duplicate bundle asset')
        source=external.get(name,root/name)
        check(source.is_file() and not source.is_symlink()
            and not any(parent.is_symlink() for parent in source.parents),'regular bundle file required')
        check(source.stat().st_size==item['bytes'] and digest(source)==item['sha256'],'bundle asset differs')
        if name==manifest['checkpoint_archive_name']:
            locations[name]=source # Opaque ZIP remains on read-only attached storage.
        else:
            target=destination/name
            with source.open('rb') as src,target.open('xb') as dst:
                shutil.copyfileobj(src,dst);dst.flush();os.fsync(dst.fileno())
            check(digest(target)==item['sha256'],'copied source differs');locations[name]=target
    template=json.loads(locations[manifest['config_template_name']].read_bytes())
    for key,name in manifest['config_bundle_paths'].items():template[key]=str(locations[name])
    template['input_root']='/kaggle/input'
    template['output_root']='/kaggle/working/shared-final-continuation'
    config=destination/'actual-bootstrap-config.json'
    with config.open('x') as f:json.dump(template,f,sort_keys=True)
    sys.path.insert(0,str(destination))
    script=locations['continuation_cloud_bootstrap_review_v2.py']
    spec=importlib.util.spec_from_file_location('reviewed_continuation_bootstrap',script)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    sys.argv=[str(script),'--config',str(config),'--config-sha256',digest(config)]
    module.main()

if __name__=='__main__':main()
